# 🟩 suvariogluinvest.github.io

This is a one-page **digital business card website** for **Yigit Suvarıoğlu**, featuring a black & gold design.

## 🚀 How to Publish on GitHub Pages

1. Go to [GitHub](https://github.com) → Create a new repository named `suvariogluinvest`.
2. Upload these files (index.html + style.css + README.md).
3. Go to **Settings → Pages** → choose `main` branch → `(root)` folder → Save.
4. Your site will go live at:  
   👉 https://YOUR-USERNAME.github.io/suvariogluinvest

## 📬 Contact Info
📧 contact@yigitsuvarioglu.com  
🌍 suvariogluinvest.github.io  
📍 London | Berlin | Paris